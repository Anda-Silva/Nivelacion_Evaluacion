package com.example.proyectofinal_2.modelos

data class Pelicula(
    val foto: String = "",
    val nombre: String = "",
    val descripcion: String = "",
    val url: String = ""
)
