package com.example.proyectofinal_2.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.proyectofinal_2.modelos.PeliculaViewModel
import com.example.proyectofinal_2.screens.*
import com.example.proyectofinal_2.screens.login.LoginScreen
import com.example.proyectofinal_2.screens.login.MainViewModel

@Composable
fun AppNavigation(
    avanza: Boolean,
    onClick: () -> Unit,
    mainViewModel: MainViewModel,
) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = AppNav.LoginScreen.route
    ) {
        composable(route = AppNav.LoginScreen.route) {
            if (avanza) {
                LaunchedEffect(key1 = Unit) {
                    navController.navigate(AppNav.Home.route)
                    {
                        popUpTo(AppNav.LoginScreen.route) {
                            inclusive = true
                        } // Fin popUpTo
                    } // Fin Modificacion
                } // Fin LaunchedEffect
            } else {
                LoginScreen(
                    navController,
                    isLoading = false,
                    onLoginClick = onClick,
                )
            } // Fin If
        } // Fin Composable
        composable(route = AppNav.Home.route) { Home(navController) }
        composable(route = AppNav.ListaPeliculas.route) {
            ListaPeliculas(
                navController,
                PeliculaViewModel()
            )
        }
        composable(route = AppNav.AddScreen.route) { AddScreen(navController) }
        composable(route = AppNav.InformacionPeli.route, arguments = listOf(
            navArgument("foto") { type = NavType.StringType },
            navArgument("nombre") { type = NavType.StringType },
            navArgument("descripcion") { type = NavType.StringType },
            navArgument("url") { type = NavType.StringType }
        )) {
            InformacionPeli(
                navController,
                foto = it.arguments?.getString("foto") ?: "",
                nombre = it.arguments?.getString("nombre") ?: "",
                descripcion = it.arguments?.getString("descripcion") ?: "",
                url = it.arguments?.getString("url") ?: ""
            ) // Fin InformacionPeli
        } // Fin composable
    } // Fin NavHost
} // Fin AppNavigation