package com.example.proyectofinal_2.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.proyectofinal_2.modelos.Pelicula
import com.example.proyectofinal_2.nav.AppNav
import com.example.proyectofinal_2.R
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar {
                Text(
                    text = "¡FORMULARIO!",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 30.sp,
                    color = Color.Black
                )
            } // Fin TopAppBar
        }, // Fin topBar
        floatingActionButton = {
            FloatingActionButton(modifier = Modifier.size(32.dp),
                onClick = { navController.navigate(route = AppNav.Home.route) }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Regresar",
                    tint = Color.White
                ) // Fin Icon
            } // Fin del FAB
        }, // Fin del FAb extreno
        floatingActionButtonPosition = FabPosition.End
    ) {
        BodyContent()
    } // Fin de BodyContent()
} // Fin AddScreen

@Composable
fun BodyContent() {
    var foto by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 30.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Image(
                    modifier = Modifier
                        .size(250.dp)
                        .clip(CircleShape)
                        .border(5.dp, MaterialTheme.colors.onBackground, CircleShape)
                        .padding(all = 10.dp),
                    painter = rememberAsyncImagePainter(R.drawable.pelicula),
                    contentDescription = "Imagenes"
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre") },
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = foto,
                    onValueChange = { foto = it },
                    label = { Text("Foto") },
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = descripcion,
                    onValueChange = { descripcion = it },
                    label = { Text("Descripcion") },
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("URL") },
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        if (foto == "" || nombre == "" || descripcion == "" || url == "") {
                            error = true
                        } else {
                            val pelicula = Pelicula(foto, nombre, descripcion, url)
                            Firebase.firestore.collection("peliculas").add(pelicula)
                        } // Fin If
                    }, //Fin onClick
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                        .fillMaxWidth()
                ) {
                    Text(text = "AGREGAR PELICULA")
                } // Fin Button
                if (error) {
                    Text(
                        text = "¡ERROR! \n ¡TODOS LOS CAMPOS DEBEN DE ESTAR LLENOS!",
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = Color.Red
                    )
                } // Fin If
            } // Fin Item
        } // Fin LazyColumn
    } // Fin Box
} // Fin BodyContent


