package com.example.proyectofinal_2.screens.login

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.Button
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.proyectofinal_2.R

@Composable
fun LoginScreen(
    navController: NavHostController,
    isLoading: Boolean,
    onLoginClick: () -> Unit,
) {
    val logo = painterResource(R.drawable.pelicula)
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceAround
    ) {
        Text(
            stringResource(R.string.Login_Title),
            style = MaterialTheme.typography.h4,
            textAlign = TextAlign.Center,
            fontFamily = FontFamily.Serif,
            fontStyle = FontStyle.Italic,
        )
        Image(
            modifier = Modifier
                .size(250.dp)
                .clip(CircleShape)
                .border(5.dp, MaterialTheme.colors.onBackground, CircleShape)
                .fillMaxWidth()
                .fillMaxHeight(0.3f)
                .padding(all = 10.dp),
            painter = logo,
            contentDescription = null
        )
        if (isLoading) {
            CircularProgressIndicator()
        } else {
            Button(
                onClick = onLoginClick,
                modifier = Modifier.border(
                    width = 10.dp,
                    color = Color.Black
                )
            ) {
                Text(stringResource(R.string.Login_cta))
            } // Fin Button
        } //  Fin If
        LegalText()
    } // Fin Column
} // Fin LoginScreen

@Composable
fun LegalText() {
    val anottatedString = buildAnnotatedString {
        append(stringResource(R.string.Text_Legal1))
        append(" ")
        pushStringAnnotation("URL", "app://terms")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.secondary
            )
        ) {
            append(stringResource(R.string.Text_Legal2))
        } // Fin withStyle
        append(" ")
        pop()
        append(stringResource(R.string.Text_Legal3))
        append(" ")
        pushStringAnnotation("URL", "app://privacy")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.secondary
            )
        ) {
            append(stringResource(R.string.Text_Legal4))
        } // Fin withStyle
        pop()
    } //fin anottatedString
    Box(contentAlignment = Alignment.Center) {
        ClickableText(
            modifier = Modifier.padding(24.dp),
            text = anottatedString
        ) { offset ->
            anottatedString.getStringAnnotations("URL", offset, offset)
                .firstOrNull()?.let { tag ->
                    Log.d("App", "Ha dado cick en ${tag.item}")
                } //fin del Offset
        } // Fin Text
    } // fin Box
} //fin LegalText
